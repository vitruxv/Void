import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Scanner;
import java.util.logging.Level;
import java.util.logging.Logger;
import org.fusesource.jansi.AnsiConsole;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
/**
 *
 * @author Mondo Diaz
 */
public class Void {

    String playername;
    int playerhp;
    int factory;
    int fighter;
    int enemyships = 2;
    int playershipcount;
    int scavenger;
    int elements;
    int bio;
    String fire;
    String upgrade;
    String move;
    String location = "A1";
    int fighterCostElement;
    String enemyshiplocation1 = "G2";
    int enemyshiphp = 5;
    int fighterCostBio;
    Scanner scanner;
    Scanner firescanner;
    String input;
    String previousgame;
    int earthMissionCount = 1;
    String playersystem;
    String playerPlanet;
    int earth;
    int mars;
    int fc;
    String cpName;
    String ansiWhiteOnBlue = "\u001b[37;44m";
    String ansiWhiteOnGreen = "\u001b[37;42m";
    String ansiNormal = "\u001b[0m";
    String ansiRed = "\u001b[31m";
    String ansiBlue = "\u001b[34m";
    String ansiGreen = "\u001b[32m";
    String ansiCyan = "\u001b[36m";
    BufferedWriter bf;
    Boolean introMission;
    int earthZ1Intro2Enemy = 1;
    int earthEnemy;
    int droneArmor;
    int mainGun;
    Boolean alert;
//        VoidGUI gui = new VoidGUI();

    public static void main(String[] args) {

        Void game = new Void();
        AnsiConsole.systemInstall();
        game.play();

    }

    public Void() {
        cpName = "CommandPal";
        scanner = new Scanner(System.in);
        firescanner = new Scanner(System.in);
        factory = 1;
        playershipcount = 5;
        playerPlanet = "earth";
        earth = 1;
        mars = 1;
        fc = 1;
        fighter = 0;
        elements = 400;
        bio = 400;
        fighterCostBio = 100;
        fighterCostElement = 100;
        introMission = true;
        mainGun = 20;
        droneArmor = 20;
        alert = false;
        

    }

    public void play() {

        intro();
        if (scanner.nextLine().equals("yes")) {
            cpName();
            renameCP();
            clearScreen();
            earth();

        } else {
            cpName();
            System.out.println(" Understood...Moving on..");
            clearScreen();
            earth();
        }

        while (enemyships > 0) {
            
            input = scanner.nextLine();
            
            if (input.equalsIgnoreCase("locate")) {
                locate();
            } else if (input.equalsIgnoreCase("fire")) {
                fire();
            } else if (input.equalsIgnoreCase("Exit")) {
                exit();
            } else if (input.equalsIgnoreCase("Save")) {
                save();
            } else if (input.equalsIgnoreCase("load")) {
                load();
            } else if (input.equalsIgnoreCase("Jump")) {
                jump();
            } else if (input.equalsIgnoreCase("scan")) {
                scan();
            } else if (input.equalsIgnoreCase("help")) {
                help();
            } else if (input.equalsIgnoreCase("build")) {
                build();
            } else if (input.equalsIgnoreCase("select")) {
                selectMenu();
            } else if (input.equalsIgnoreCase("action")) {
                actionMenu();
            } else {
                inputError();
            }

            if (playerPlanet.equalsIgnoreCase("Earth")) {

                earth();
            }
            if (playerPlanet.equalsIgnoreCase("Mars")) {
                mars();
            }
            if (playerPlanet.equalsIgnoreCase("Fleet Command")) {
                fleetcommand();
            }

        }

    }

    private void selectMenu() {
        String selectInput;
        AnsiConsole.out().print(ansiWhiteOnBlue + "[" + cpName + "]" + ansiNormal);
        System.out.println(" Scanning for ships...");
        AnsiConsole.out().print(ansiWhiteOnBlue + "[" + cpName + "]" + ansiNormal);
        System.out.println(" You have...");

        System.out.println(fighter + "." + "Predator(s)");

        System.out.println(scavenger + "." + "Scavenger(s)");

        System.out.println(factory + "." + "Factory(s)\n");
        AnsiConsole.out().print(ansiWhiteOnBlue + "[" + cpName + "]" + ansiNormal);
        System.out.println(" Please make selection...");
        System.out.println("1.Predator(s)");
        System.out.println("2.Scavenger(s)");
        System.out.println("3.Factory(s)");
        
        selectInput = scanner.nextLine();
        if (selectInput.equalsIgnoreCase("1") && fighter > 0) {
            System.out.println("\n Predator(s) Selected...");

            System.out.println("1.Group-Link");
            System.out.println("2.Individual");
            
            scanner.nextLine();
            if (selectInput.equalsIgnoreCase("1")) {
                System.out.println(" Group-Link initiated....");
                System.out.println(fighter + " Predator(s) Selected");
                
            }
        } else if (input.equalsIgnoreCase("2")) {

            System.out.println(" Scavenger Selected...");

            
        } else if (input.equalsIgnoreCase("3")) {

            System.out.println(" Factory Selected...");

            
        }

    }

    public void factory() {
        System.out.println("Factory built");
        factory++;
        System.out.println("You now have " + factory + " Factory(s)");
    }

    public void scavenger() {
        System.out.println("Scavenger built");
        scavenger++;
        System.out.println("You now have " + scavenger + " Scavenger(s)");
    }

    public void locate() {
        System.out.println("\nProcessing.....");
        System.out.println("..............................");
        System.out.println(playername + " is located at " + playerPlanet);
        System.out.println("..............................");
        System.out.println("Ready....");
        

    }

    public void exit() {
        System.out.println("\nNow exiting game.....\n");
        System.exit(0);
    }

    public void inputError() {
        clearScreen();
        resMenuBar();
        cpName();
        System.out.println(" System Error..Please Try again.");
        

    }

    public void scan() {
        if (playerPlanet.equalsIgnoreCase("Earth")) {
            clearScreen();
            resMenuBar();
            cpName();
            System.out.println(" You have " + earthMissionCount + " mission(s) in this sector.");
            pause1();
            cpName();
            System.out.println(" There are " + earthZ1Intro2Enemy + " enemy(s) in range.");
        }

    }

    public void fire() {
        clearScreen();
        resMenuBar();
        AnsiConsole.out().print(ansiRed + "<" + "Select Targets" + ">" + ansiNormal);
        if (playerPlanet.equalsIgnoreCase("earth")){
            System.out.println("\n1.Drone");
            input = scanner.nextLine();
            if (input.equalsIgnoreCase("1")){
                if (mainGun >= droneArmor){
                    droneArmor = droneArmor - mainGun;
                    if (droneArmor > 0){
                    System.out.println(" Drone has " + droneArmor + " armor left");
                    }
                    else if (droneArmor < 0){
                        earthZ1Intro2Enemy = earthZ1Intro2Enemy - 1;
                        System.out.println(" Drone has been destroyed...");
                    }
                }
            }
        }
        else if(playerPlanet.equalsIgnoreCase("mars")){
            System.out.println("\n1.Mars Enemies");
        }

        input = scanner.nextLine();
        if (input.equalsIgnoreCase("1")) {
            

        } else {
            
            inputError();
            
            
        }
    }

    private void jump() {
        System.out.println("\nLoading Jump List...");
        System.out.println("....SOL System....");
        System.out.println("1.Earth");
        System.out.println("2.Mars");
        System.out.println("3.Fleet Command");
        String linput = scanner.nextLine();
        if (linput.equalsIgnoreCase("1")) {
            playerPlanet = "Earth";
            earth = 1;
        } else if (linput.equals("2")) {
            playerPlanet = "Mars";
            mars = 1;
        } else if (linput.equals("3")) {
            playerPlanet = "Fleet Command";
            fc = 1;
        }

        System.out.println("\nPreparing to Jump......");
        System.out.println("\nJumping.....");
        System.out.println("\nJump Complete.");
        System.out.println("\nArrived at " + playerPlanet);
        System.out.println("\nReady....");
        
    }

    private void save() {
        try {
            System.out.println("Saving............");
            File f = new File(playername + ".txt");
            FileWriter fw = new FileWriter(playername + ".txt", true);
            bf = new BufferedWriter(fw);
            bf.write("1");
            bf.newLine();
            bf.write(playername);
            bf.newLine();
            bf.write(location);
            bf.newLine();
            bf.write(playershipcount);
            bf.newLine();
            bf.write(playerhp);
            bf.newLine();

            bf.newLine();

            bf.close();
            System.out.println("Ready....");
            System.out.printf(">");
        } catch (IOException e) {

            e.printStackTrace();

        }
    }

    private void load() {
        System.out.println("Loading previous game.....");
        try {
            FileReader fr = new FileReader(playername + ".txt");
            BufferedReader br = new BufferedReader(fr);

            previousgame = br.readLine();
            playername = br.readLine();
            location = br.readLine();

            br.close();
            System.out.println("Ready....");

        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }

    }

    private void fighter() {
        System.out.println("Predator Built.");
        fighter++;
        bio = bio - fighterCostBio;
        elements = elements - fighterCostElement;
        clearScreen();
        resMenuBar();
        System.out.println("You now have " + fighter + " Predator(s)");
//        System.out.println("\n" +
//"           ||\n" +
//"/_________/[]\\_________\\  \n" +
//"\\_________\\[]/_________/\n");
        System.out.println("\n" +
"  	    ||	\n" +
"        \\--|OO|--/\n" +
"    \\======/[]\\======/\n" +
"<xxx------|----|------xxx>\n" +
"    /======\\[]/======\\\n" +
"       oO0Oo  oO0Oo\n" +
"           \\--/\n");
        pause2();

    }

    private void build() {
        clearScreen();
        resMenuBar();
        if (factory > 0) {
            cpName();
            System.out.println(" Locating Factory...");
            pause2();
            cpName();
            System.out.println(" Factory Located...");
            pause1();
            cpName();
            System.out.println(" Link established...");
            pause1();
            cpName();
            System.out.println(" Loading build options...");
            pause1();
            clearScreen();
            resMenuBar();
            buildMenu();
            System.out.println("\n1.Predator " + "Bio:" + fighterCostBio + " Elements:" + fighterCostElement);
            System.out.println("2.Scavenger");
            System.out.println("3.Factory");
            String binput = scanner.nextLine();

            if (binput.equalsIgnoreCase("1")) {
                if (bio > fighterCostBio && elements > fighterCostElement) {
                    clearScreen();
                    resMenuBar();
                    buildMenu();
                    System.out.println("Building Predator...");
                    fighter();
                    
                } else {
                    buildMenu();
                    System.out.println(" \nYou do not have enough resources..");
                    
                }
            } else if (binput.equalsIgnoreCase("2")) {
                buildMenu();
                System.out.println(" \nBuilding Scavenger...");
                scavenger();
                
            } else if (binput.equalsIgnoreCase("3")) {
                buildMenu();
                System.out.println(" \nBuilding Factory...");
                factory();
                
            }
        } else {
            buildMenu();
            System.out.println(" \nFactory not Online...");
            
        }
        if (introMission == true) {
            intromission2();
        }

    }

    private void intro() {
        clearScreen();
        System.out.println(ansiRed + "____   ____    .__    .___\n"
                + "\\   \\ /   /___ |__| __| _/\n"
                + " \\   Y   /  _ \\|  |/ __ | \n"
                + "  \\     (  <_> )  / /_/ | \n"
                + "   \\___/ \\____/|__\\____ | \n"
                + "                       \\/ " + ansiNormal);

        System.out.println("Pre-Alpha" + "\n\n");
        pause2();
        System.out.println("Systems initiating...");
        pause2();
        System.out.println("Ready.");
        pause1();
        System.out.println("Connecting to Fleet Command...");
        pause2();
        System.out.println("Link Established.");
        pause1();
        System.out.println("Complete.");
        pause1();
        System.out.println("Activating CommandPal...");
        pause2();
        System.out.println("CommandPal Active.");
        pause2();
        clearScreen();
        resMenuBar();
        cpName();
        System.out.println(" Hello, I am a Nantech CommandPal 5000.");
        pause2();

        cpName();
        System.out.println(" Like all CommandPals, I am to assist you with your fleet.");
        pause2();
        cpName();
        System.out.println(" Would you like to rename me? (yes or no)");
        pause2();

    }

    private void help() {

        System.out.println("\n............................");
        System.out.println("<Load>");
        System.out.println("<Save>");
        System.out.println("<Fire>");
        System.out.println("<Jump>");
        System.out.println("<Locate>");
        System.out.println("<Channel> (Not Ready)");
        System.out.println("<Exit>");
        System.out.println("<Scan> (Not Ready)");
        System.out.println("............................\n\n");

        
    }

    private void earth() {
        if (earth == 1) {
            resMenuBar();
            cpName();
            System.out.println(" Scanning region...");
            pause2();
            cpName();
            System.out.println(" Scan Complete.");
            clearScreen();
            resMenuBar();
            cpName();
            AnsiConsole.out().println(ansiRed + " [Location: Earth]" + ansiNormal);
            pause2();
            introMission();
            earth = 0;

        }
    }

    private void mars() {
        if (mars == 1) {
            System.out.println("\nScanning region.....Scan Complete.");

            System.out.println(".....Mars......");

            System.out.println(earthMissionCount + " missions are available\n\n");

            
            mars = 0;
        }
    }

    private void fleetcommand() {
        if (fc == 1) {
            System.out.println("\nScanning region.....Scan Complete.");

            System.out.println(".....Fleet Command......");

            System.out.println(earthMissionCount + " missions are available\n\n");

            
            fc = 0;
        }
    }

    private void clearScreen() {
        System.out.print("\u001b[2J");
        System.out.flush();
    }

    private void cpName() {
        AnsiConsole.out().print(ansiCyan + "<" + cpName + ">" + ansiNormal);
    }

    private void buildMenu() {
        AnsiConsole.out().print(ansiRed + "<" + "Build" + ">" + ansiNormal);
    }

    private void res() {
        clearScreen();
        AnsiConsole.out().print(ansiRed + "\n<" + "Resources" + ">\n" + ansiNormal);
        System.out.println("Elements:" + elements);
        System.out.println("Biomatter:" + bio);
    }

    private void introMission() {
        cpName();
        System.out.println(" Incoming Transmission from Admiral Crow.");
        cpName();
        System.out.println(" Connecting...Channel Open.");
        pause3();
        clearScreen();
        resMenuBar();
        admCrow();
        System.out.println(" Welcome to the Fleet, Commander...");
        pause1();
        admCrow();
        System.out.println(" We need to bring you up to speed on your CommandPal...");
        pause1();
        admCrow();
        System.out.println(" You can issue your CommandPal commands...");
        pause1();
        admCrow();
        System.out.println(" Let's start with controlling a Factory... ");
        pause1();
        admCrow();
        System.out.println(" Link to a Factory Ship by using the " + ansiRed + "<Build>" + ansiNormal + " command...");
        pause1();

    }

    private void intromission2() {
        clearScreen();
        resMenuBar();
        cpName();

        System.out.println(" Incoming Transmission from Admiral Crow.");
        pause1();
        cpName();
        System.out.println(" Connecting..Channel Open.");
        pause1();
        clearScreen();
        admCrow();
        System.out.println(" Well Done!");
        pause1();
        admCrow();
        System.out.println(" Now that you have built your first Predator...");
        pause1();
        admCrow();
        System.out.println(" Lets give it something to shoot at, shall we?");
        pause1();
        admCrow();
        System.out.println(" I am ordering a Drone to your location....");
        pause1();
        admCrow();
        System.out.println(" Let's see if you can shoot it down..");
        pause1();
        admCrow();
        System.out.println(" Use the <Action> menu to find and destroy that drone...");
        
        

    }

    private void pause1() {
        try {
            Thread.sleep(1000);
        } catch (InterruptedException ex) {
            Logger.getLogger(Void.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    private void pause2() {
        try {
            Thread.sleep(2000);
        } catch (InterruptedException ex) {
            Logger.getLogger(Void.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    private void pause3() {
        try {
            Thread.sleep(3000);
        } catch (InterruptedException ex) {
            Logger.getLogger(Void.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    private void pause4() {
        try {
            Thread.sleep(4000);
        } catch (InterruptedException ex) {
            Logger.getLogger(Void.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    private void pause5() {
        try {
            Thread.sleep(5000);
        } catch (InterruptedException ex) {
            Logger.getLogger(Void.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    private void renameCP() {
        System.out.println(" Please input new Designation");
        cpName = scanner.nextLine();
    }

    private void resMenuBar() {
        System.out.println("*****************************************************");
        System.out.println(ansiRed + " Bio:" + bio + "  Elements:" + elements + "  Predators:" + fighter + "  Scavengers:" + scavenger + ansiNormal);
        System.out.println("*****************************************************\n\n\n");
    }

    private void admCrow() {
        AnsiConsole.out().print(ansiGreen + "<" + "Admiral Crow" + ">" + ansiNormal);
    }
    
    private void actionMenu() {
    clearScreen();
    resMenuBar();
        
    System.out.println(ansiRed + "<Action>" + ansiNormal);
    System.out.println("1.Scan");
    System.out.println("2.Attack");
    System.out.println("3.Build");
    System.out.println("4.Select");
    System.out.println("5.Jump");
    System.out.println("6.Help");
    input = scanner.nextLine();
    if (input.equalsIgnoreCase("2")){
        fire();
    }
    else{
        inputError();
        
                }
    }
}
